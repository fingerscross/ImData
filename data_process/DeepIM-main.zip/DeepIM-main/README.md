# DeepIM

The code has been tested under Pytorch 1.8

To test the code, simply run the following command  
```
cd <DeepIM>
python genim.py -d <datasetname>
```
Datasets names are 'jazz', 'power_grid', 'cora_ml', 'netscience', 'random5'
Run the following code to see available parameters that can be passed in:  
```
python genim.py -h
```
